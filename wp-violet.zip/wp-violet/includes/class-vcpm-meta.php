<?php
/**
 * Meta boxes and their functions 
 *
 * @link       www.rakibhossain.cf
 * @since      1.0.0
 *
 * @package    Vcpm
 * @subpackage Vcpm/includes
 */

class Vcpm_Meta
{

/**
 * Get all posts
 * 
 * @return array
 */
public static function vcpm_team_list() {
  $pages    = array();
  $pages['-1'] = 'Select';
  foreach ( get_posts(array( 'post_type' => 'team')) as $page ) {
    $pages[ $page->ID ] = $page->post_title;
  }

  return $pages;
}

    public static function vcpm_meta_box(){

        $rating_list = array(1,2,3,4,5);

        $team_fields = array(
            array(
                'name' => __('Position', 'vcpm'),
                'desc' => '',
                'id' => 'team_position',
                'type' => 'text'
            )
        );

        $post_fields = array(
            array(
                'name' => __('Author name', 'vcpm'),
                'desc' => '',
                'id' => 'sub_name',
                'type' => 'text'
            ),
            array(
                'name' => __('Author image', 'vcpm'),
                'desc' => '',
                'id' => 'portfolio_img',
                'type' => 'portfolio'
            ),
            array(
                'name' => __('Author', 'vcpm'),
                'desc' => '',
                'id' => 'author_name',
                'type' => 'team',
                "options" => self::vcpm_team_list()
            ),
            array(
                'name' => __('Show on feature area', 'vcpm'),
                'desc' => '',
                'id' => 'butterfly_feature_area',
                'type' => 'checkbox',
                'options' => array(['name'=> 'Yes', 'value'=>1])
            )
        );

        $data['team'] = array(
            'id' => 'team-meta-box',
            'title' =>  __('Additional Info', 'vcpm'),
            'page' => 'team',
            'context' => 'normal',
            'priority' => 'high',
            'fields' => apply_filters('vcpm_meta_fields_team', $team_fields)
        );

        $data['post'] = array(
            'id' => 'post-meta-box',
            'title' =>  __('Author Info', 'vcpm'),
            'page' => 'post',
            'context' => 'normal',
            'priority' => 'high',
            'fields' => apply_filters('vcpm_meta_fields_post', $post_fields)
        );
        return apply_filters('vcpm_meta_box',$data);
    }


public function butterfly_cpt_columns( $columns ) {
    $columns["butterfly_feature_area"] = "Show Top";
    return $columns;
}

public function butterfly_cpt_column( $colname, $cptid ) {
     if ( $colname == 'butterfly_feature_area'){
        echo '<input type="checkbox" disabled', ( (get_post_meta( $cptid, 'butterfly_feature_area', true ) == 1) ? ' checked' : ''), '/>';
     }
}
    /**
	* Meta box array.
	*/
	protected $meta_box;

    /**
    * Current post type.
    */
    protected $post_type;

    /**
    * Add meta box.
    */
    public function add()
    {  
        $this->meta_box = self::vcpm_meta_box();     

        foreach ($this->meta_box as $meta_item) {

            add_meta_box($meta_item['id'], $meta_item['title'], [$this,'show_meta_box'], $meta_item['page'], $meta_item['context'], $meta_item['priority']);  
        }

    }
 
    /**
     * Save data from meta box.
     */
    public function save($post_id) {

         $this->meta_box = self::vcpm_meta_box();

        if (array_key_exists(get_post_type($post_id),$this->meta_box))
          {
            $this->post_type =  get_post_type($post_id);
          }else{
            return $post_id;
          }
        
        /**
         * verify nonce.
         */       
        if (!isset($_POST[$this->meta_box[$this->post_type]['id'].'_nonce']) || !wp_verify_nonce($_POST[$this->meta_box[$this->post_type]['id'].'_nonce'], basename(__FILE__))) {
            return $post_id;
        }
        
        /**
         * Check autosave.
         */
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return $post_id;
        }
        
        /**
         * check permissions.
         */
        if ('page' == $_POST['post_type']) {
            if (!current_user_can('edit_page', $post_id)) {
                return $post_id;
            }
        } else if (!current_user_can('edit_post', $post_id)) {
            return $post_id;
        }
        
        /**
         * Update meta box value.
         */
        foreach ($this->meta_box[$this->post_type]['fields'] as $field) {
            $new = isset($_POST[$field['id']]) ? $_POST[$field['id']] : '';

            switch ($field['type']) {
                case 'text':
                    $new = sanitize_text_field($new);
                    break;
                case 'select':
                    $new = sanitize_text_field($new);
                    break;
                case 'team':
                    $new = sanitize_text_field($new);
                    break;
                case 'radio':
                    $new = sanitize_text_field($new);
                    break;
                case 'checkbox':
                    $new = sanitize_text_field($new);
                    break;
                case 'color':
                    $new = sanitize_hex_color($new);
                    break;
                case 'range':
                    $new = absint($new);
                    break;
                case 'portfolio':
                    $new = esc_url($new);
                    break;
                case 'url':
                    $new = esc_url($new);
                    break;
                default:
                    $new = sanitize_text_field($new);
            }

            update_post_meta($post_id, $field['id'], $new);
        }
    }
 
    /**
     * Callback function to show fields in meta box.
     */
    public function show_meta_box($post) {

        if (array_key_exists(get_post_type( $post->ID ),$this->meta_box))
          {
            $this->post_type =  get_post_type( $post->ID );

            // Use nonce for verification
            wp_nonce_field( basename( __FILE__ ), $this->meta_box[$this->post_type]['id'].'_nonce' );
            $this->vcpm_meta_fields($this->meta_box[$this->post_type]['fields'], $post);

          }else{
            return;
          }
    }    

    /**
     * Meta box data show according to their input type.
     */
    protected function vcpm_meta_fields($meta__fields, $post){
        $html = '';
        $html .= '<table class="form-table vcpm-table">';
        foreach ($meta__fields as $field) {
            // get current post meta data
            $meta = get_post_meta($post->ID, $field['id'], true);

            $html.= '<tr>
            
                <th style="width:20%">
                    <label for="'. $field['id']. '">
                        <strong>'. $field['name']. '</strong>
                    </label>
                </th>

                <td style="margin:0;padding:0;">';
            switch ($field['type']) {
                case 'info':
                    $html .= '<h3 style="margin:0;padding:0;">'.$field['desc'].'</h3>';
                    break;
                case 'text':
                    $html .= '<input type="text" title="'.$field['desc'].'" name="'. $field['id']. '" id="'. $field['id']. '" value="'. $meta. '" class="vcpm-text" />';
                    break;



                case 'team':
                    $html.= '<select name="'. $field['id']. '" title="'.$field['desc'].'" id="'. $field['id']. '" style="min-width:30%">';
                    $html_select ='';
                    foreach ($field['options'] as $value => $label) {





                        // $opt = explode('|', $option);


                        // if (count($opt) == 1) $opt[1] = strtolower($opt[0]);



                        $html_select .= '<option '. selected( $meta, $value, false ). ' value="' . $value . '"' . '>'. $label. '</option>';


                    }
                    $html.= $html_select.'</select>';
                    break;




                case 'select':
                    $html.= '<select name="'. $field['id']. '" title="'.$field['desc'].'" id="'. $field['id']. '" style="min-width:30%">';
                    $html_select ='';
                    foreach ($field['options'] as $option) {
                        $opt = explode('|', $option);
                        if (count($opt) == 1) $opt[1] = strtolower($opt[0]);
                        $html_select .= '<option '. selected( $meta, $opt[1], false ). ' value="' . $opt[1] . '"' . '>'. $opt[0]. '</option>';
                    }
                    $html.= $html_select.'</select>';
                    break;
                case 'radio':
                    foreach ($field['options'] as $option) {

                        $html.= '<label class="mr-10"><input type="radio" name="'. $field['id']. '" title="'.$field['desc'].'" value="'. $option['value']. '"'.checked( $option['value'], $meta, false ).' />'. $option['name'] . '</label>';
                    }
                    break;
                case 'checkbox':
                    $arr = explode(',',$meta);
                    $html.= '<div class="multiple__checkbox">';

                    foreach ($field['options'] as $option) {
                        $option_value = strtolower($option['value']);
                        $option_value = preg_replace('/\s+/', '_', $option_value);
                        $checked = in_array($option_value, $arr) ? ' checked="checked"' : '';

                        $html.= '<input title="'.$field['desc'].'" class="single__checkbox" id="'.$option_value.'id" type="checkbox" value="'. $option_value. '"'.$checked.' /><label class="mr-10" for="'.$option_value.'id">'.$option['name'].'</label>';
                    }
                    $html.= '
                    <input type="hidden" class="multiple__checkbox__value" name="'. $field['id']. '" id="'. $field['id']. '" value="'. $meta. '" /></div>';
                    break;
                case 'color':
                    $html.= '<input type="hidden" class="color_field"  name="'. $field['id']. '" id="'. $field['id']. '" value="'. $meta. '" style="min-width:30%" /><br />'. '<span class="meta-desc">'. $field['desc'].'</span>';
                    break;
                case 'range':
                    $html.= '
                        <div class="range-slider">
                            <input class="range-slider__range"  title="'.$field['desc'].'" type="range" name="'. $field['id']. '" id="'. $field['id']. '" value="'. $meta. '" min="0" max="100">
                            <span class="range-slider__value">'. $meta. '</span>
                        </div>';
                    break;
                case 'portfolio':
                    $url = esc_url($meta);
                    $html.= '<button type="button" title="'.$field['desc'].'" class="button" id="img-'. $field['id']. '">Choce</button>';
                    if ($meta=='') {
                        $html.= '<div class="port_img_preview none"><img src="'. $url.'" id="port_img_preview" alt="File not selected" style="width: 200px; height: auto;"></div>'; 
                    }else{
                        $html.= '<div class="port_img_preview"><img src="'. $url.'" id="port_img_preview" alt="Portfolio" style="width: 200px; height: auto;"></div>'; 
                    }
                    $html.= '<input type="hidden" name="'. $field['id']. '" id="'. $field['id']. '" value="'. $url. '"/>';
                    break;
                default:
                    $html .= '<input type="text" title="'.$field['desc'].'" name="'. $field['id']. '" id="'. $field['id']. '" value="'. $meta. '" class="vcpm-text" />';
            }

            $html.= '</td></tr>';

        }
        $html .= '</table>';

        echo apply_filters('vcpm_meta_fields_control', $html, $meta__fields, $post);
    }
}